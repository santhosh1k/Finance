<?php
$servername    =   "localhost";
$username      =   "root";
$dbpassword    =    "";
$dbname        =    "admin_role";
$con           =   mysqli_connect($servername,$username,$dbpassword,$dbname) or die (mysqli_error());
?>
